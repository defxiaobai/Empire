// JavaScript Document
<!--
function menu_on(x,id,y)

{

for(i=1;i<=y;i++)

{
document.getElementById("menu_"+x+"_"+i+"_"+y).className = "";

document.getElementById("cont_"+x+"_"+i+"_"+y).style.display = "none";

}


document.getElementById("menu_"+x+"_"+id+"_"+y).className = "active";

document.getElementById("cont_"+x+"_"+id+"_"+y).style.display = "block";

} 

$('#txt_x').click(function(){
						$('.left_zw').css('font-size','12px');  
						$('#txt_z').removeClass("on");
						$('#txt_d').removeClass("on");
						$('#txt_x').addClass("on");

						  });
$('#txt_z').click(function(){
						$('.left_zw').css('font-size','15px');  
						$('#txt_x').removeClass("on");
						$('#txt_d').removeClass("on");
						$('#txt_z').addClass("on");

						  });
$('#txt_d').click(function(){
						$('.left_zw').css('font-size','18px');  
						$('#txt_z').removeClass("on");
						$('#txt_x').removeClass("on");
						$('#txt_d').addClass("on");

						  });

$('#menu_1_1_2').click(function(){
						$('#menu_1_2_2').removeClass("active");	
						$('#menu_1_1_2').addClass("active");
						$('#cont_1_1_2').slideUp();
							$('#cont_1_1_2').slideDown();
						$('#cont_1_2_2').hide();	
					
								});
$('#menu_1_2_2').click(function(){
						$('#menu_1_1_2').removeClass("active");	
						$('#menu_1_2_2').addClass("active");
						$('#cont_1_2_2').show();
						$('#cont_1_1_2').slideUp();	
});

jQuery(document).ready(function(){
	jQuery('#menus > li').each(function(){
		jQuery(this).hover(

			function(){
				jQuery(this).find('ul:eq(0)').show();
			},

			function(){
				jQuery(this).find('ul:eq(0)').hide();
			}

		);
	});
});

function xzfl(fl){
	if (fl ==1){
		document.getElementsByName('search_fl').value='title';
				$('#menus li span').html("����<input name='search_fl' id='search_fl' value='title' type='hidden' />");

		
		}
		if (fl ==2){
		document.getElementsByName('search_fl').value='content';
		$('#menus li span').html("����<input name='search_fl' id='search_fl' value='content' type='hidden' />");
		
		}
		if (fl ==3){
		document.getElementsByName('search_fl').value='pic';
				$('#menus li span').html("ͼƬ<input name='search_fl' id='search_fl' value='pic' type='hidden' />");

		}
		if (fl ==4){
		document.getElementsByName('search_fl').value='sp';
				$('#menus li span').html("��Ƶ<input name='search_fl' id='search_fl' value='sp' type='hidden' />");

		}
		document.getElementById('child').style.display='none';
	
	}

function submitFun() {
var hotword="";
hotword=document.getElementsByName('q')[0].value;
var field=document.getElementsByName('search_fl').value;
if (field=='title'){
window.open("http://sou.chinanews.com.cn/search.do?q=title:"+encodeURIComponent(hotword));
 }else if(field=='content'){
 window.open("http://sou.chinanews.com.cn/search.do?q="+encodeURIComponent(hotword));
 }else if(field=='pic'){
 window.open("http://sou.chinanews.com.cn/imgsearch.do?q="+encodeURIComponent(hotword));
 }else if(field=='sp'){
 window.open("http://sou.chinanews.com.cn/spsearch.do?q="+encodeURIComponent(hotword));
}
else{
	window.open("http://sou.chinanews.com.cn/search.do?q=title:"+encodeURIComponent(hotword));

	}
}
-->
